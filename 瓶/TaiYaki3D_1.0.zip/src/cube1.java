import java.io.IOException;


import basic.TPoint3D;
import camera.TFrame;
import object3D.TCube;

public class cube1 {
	public static void main(String args[]) throws IOException{
		TFrame frame = new TFrame(500,500);
		TCube cube = new TCube(new TPoint3D(0,0,0),100);
		frame.add(cube);
		try {
			frame.View();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}