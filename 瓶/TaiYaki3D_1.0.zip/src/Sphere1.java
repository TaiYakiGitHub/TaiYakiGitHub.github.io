
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import basic.TPoint3D;
import camera.TFrame;
import object3D.TSphere;
import pattern.TImage;

public class Sphere1 {
	public static void main(String args[]) throws IOException{
		TFrame frame = new TFrame(500,500);
		TSphere cube = new TSphere(new TPoint3D(0,0,0),100);
		cube.pattern = new TImage(ImageIO.read(new File("Java Ico.jpg")));
		frame.add(cube);
		try {
			frame.View();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}