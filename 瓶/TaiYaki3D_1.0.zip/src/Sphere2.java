
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import basic.TPoint3D;
import camera.TFrame;
import object3D.TSphere;
import pattern.TImage;
import pattern.TPattern;

public class Sphere2 {
	public static void main(String args[]) throws IOException{
		TFrame frame = new TFrame(500,500);
		TSphere cube = new TSphere(new TPoint3D(0,0,0),100);
		cube.pattern = new TImage(ImageIO.read(new File("Java Ico.jpg")));
		cube.pattern.mapping_type = TPattern.PARALlEL_MAPPING;
		frame.add(cube);
		try {
			frame.View();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}